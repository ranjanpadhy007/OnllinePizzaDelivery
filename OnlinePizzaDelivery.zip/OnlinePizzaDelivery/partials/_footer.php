<div class="footer container-fluid bg-dark text-light">
    <p class="text-center py-2 mb-0">Copyright © 2023 Designed by <span><a href="https://github.com/ranjanpadhy007" target="_blank" rel="noopener noreferrer">@ranjan...</a></span><a href="https://github.com/Shrutie03" target="_blank" rel="noopener noreferrer">@shruti...</a><a href="https://github.com/HRPUKALE" target="_blank" rel="noopener noreferrer">@harshad...</a><a href="https://github.com/suraj8299" target="_blank" rel="noopener noreferrer">@suraj...</a></p>
</div>
